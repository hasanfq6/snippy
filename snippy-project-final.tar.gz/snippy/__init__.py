"""
snippy - Store, search, and summon code snippets right from your terminal.
"""

__version__ = "0.1.0"
__author__ = "OpenHands"
__email__ = "openhands@all-hands.dev"